<div class="col-md-12 content content_dash">
	<a href="<?=base_url('pos/etalase/')?>">
		<div class="member_card_style">
			<div class="row row-dash">
				<div class="col_row_first">
					<div class="row">
						<div class="col_row_content_first d-flex align-items-center justify-content-center">
							<img src="<?=base_url('assets/icons/icon_svg/clipboard.svg')?>" class="img-dash">
						</div>
						<div class="col_row_content_seccond d-flex align-items-center">
							<span class="text-title-dash"><strong>ETALASE</strong></span>
						</div>
					</div>
				</div>
				<div class="col_row_seccond d-flex justify-content-end">
					<div class="card d-flex align-items-center justify-content-center" style="width: 100px;border: 0;">
						<i class="fas fa-angle-double-right fa-3x"></i>
					</div>
				</div>
			</div>
		</div>
	</a>
</div>