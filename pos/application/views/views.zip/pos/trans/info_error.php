<div class="col-md-12 d-flex align-items-center justify-content-center">
	<img src="<?=base_url('assets/icons/icon_svg/background/info_error.svg')?>" class="img_info" style="width: 150px; height: 150px;">
</div>
<div>&nbsp;</div>
<div class="col-md-12 text-center">
	<span class="text-title-head"><strong>Error !</strong></span>
</div>
<div>&nbsp;</div>
<div class="col-md-12 text-center">
	<span class="text-title-head"><strong>Terjadi kesalahan, harap coba lagi nanti.</strong></span>
</div>
<div>&nbsp;</div>
<div class="col-md-12">
	<a href="<?=base_url('pos/')?>">
		<div class="member_card_style_idb d-flex align-items-center justify-content-center">
			<div class="row">
				<div class="col d-flex align-items-center justify-content-center">
					<span class="text-title-idb"><strong>Ok !</strong></span>
				</div>
			</div>
		</div>
	</a>
</div>
<div>&nbsp;</div>
<div>&nbsp;</div>
<div>&nbsp;</div>
<div>&nbsp;</div>
<div>&nbsp;</div>
<div>&nbsp;</div>