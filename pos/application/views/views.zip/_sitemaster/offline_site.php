<div class="rows">
	<img src="<?php echo base_url('assets/logo/under-construction.png'); ?>" class="img-fluid"/>
	<div class="col-md-12">
		<h2>
			<b>
				YOU ARE OFFLINE NOW PLEASE CHECK YOUR INTERNET CONNECTION.
			</b>
		</h2>
	</div>
</div>