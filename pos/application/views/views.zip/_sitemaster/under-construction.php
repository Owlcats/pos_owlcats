<img src="<?php echo base_url('assets/logo/under-construction.png'); ?>" class="img-fluid"/>
